(function($){
    "use strict";
    
    let $tourm_page_breadcrumb_area      = $("#_tourm_page_breadcrumb_area");
    let $tourm_page_settings             = $("#_tourm_page_breadcrumb_settings");
    let $tourm_page_breadcrumb_image     = $("#_tourm_breadcumb_image");
    let $tourm_page_title                = $("#_tourm_page_title");
    let $tourm_page_title_settings       = $("#_tourm_page_title_settings");

    if( $tourm_page_breadcrumb_area.val() == '1' ) {
        $(".cmb2-id--tourm-page-breadcrumb-settings").show();
        if( $tourm_page_settings.val() == 'global' ) {
            $(".cmb2-id--tourm-breadcumb-image").hide();
            $(".cmb2-id--tourm-page-title").hide();
            $(".cmb2-id--tourm-page-title-settings").hide();
            $(".cmb2-id--tourm-custom-page-title").hide();
            $(".cmb2-id--tourm-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--tourm-breadcumb-image").show();
            $(".cmb2-id--tourm-page-title").show();
            $(".cmb2-id--tourm-page-breadcrumb-trigger").show();
    
            if( $tourm_page_title.val() == '1' ) {
                $(".cmb2-id--tourm-page-title-settings").show();
                if( $tourm_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--tourm-custom-page-title").hide();
                } else {
                    $(".cmb2-id--tourm-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--tourm-page-title-settings").hide();
                $(".cmb2-id--tourm-custom-page-title").hide();
    
            }
        }
    } else {
        $tourm_page_breadcrumb_area.parents('.cmb2-id--tourm-page-breadcrumb-area').siblings().hide();
    }


    // breadcrumb area
    $tourm_page_breadcrumb_area.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--tourm-page-breadcrumb-settings").show();
            if( $tourm_page_settings.val() == 'global' ) {
                $(".cmb2-id--tourm-breadcumb-image").hide();
                $(".cmb2-id--tourm-page-title").hide();
                $(".cmb2-id--tourm-page-title-settings").hide();
                $(".cmb2-id--tourm-custom-page-title").hide();
                $(".cmb2-id--tourm-page-breadcrumb-trigger").hide();
            } else {
                $(".cmb2-id--tourm-breadcumb-image").show();
                $(".cmb2-id--tourm-page-title").show();
                $(".cmb2-id--tourm-page-breadcrumb-trigger").show();
        
                if( $tourm_page_title.val() == '1' ) {
                    $(".cmb2-id--tourm-page-title-settings").show();
                    if( $tourm_page_title_settings.val() == 'default' ) {
                        $(".cmb2-id--tourm-custom-page-title").hide();
                    } else {
                        $(".cmb2-id--tourm-custom-page-title").show();
                    }
                } else {
                    $(".cmb2-id--tourm-page-title-settings").hide();
                    $(".cmb2-id--tourm-custom-page-title").hide();
        
                }
            }
        } else {
            $(this).parents('.cmb2-id--tourm-page-breadcrumb-area').siblings().hide();
        }
    });

    // page title
    $tourm_page_title.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--tourm-page-title-settings").show();
            if( $tourm_page_title_settings.val() == 'default' ) {
                $(".cmb2-id--tourm-custom-page-title").hide();
            } else {
                $(".cmb2-id--tourm-custom-page-title").show();
            }
        } else {
            $(".cmb2-id--tourm-page-title-settings").hide();
            $(".cmb2-id--tourm-custom-page-title").hide();

        }
    });

    //page settings
    $tourm_page_settings.on("change",function(){
        if( $(this).val() == 'global' ) {
            $(".cmb2-id--tourm-breadcumb-image").hide();
            $(".cmb2-id--tourm-page-title").hide();
            $(".cmb2-id--tourm-page-title-settings").hide();
            $(".cmb2-id--tourm-custom-page-title").hide();
            $(".cmb2-id--tourm-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--tourm-breadcumb-image").show();
            $(".cmb2-id--tourm-page-title").show();
            $(".cmb2-id--tourm-page-breadcrumb-trigger").show();
    
            if( $tourm_page_title.val() == '1' ) {
                $(".cmb2-id--tourm-page-title-settings").show();
                if( $tourm_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--tourm-custom-page-title").hide();
                } else {
                    $(".cmb2-id--tourm-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--tourm-page-title-settings").hide();
                $(".cmb2-id--tourm-custom-page-title").hide();
    
            }
        }
    });

    // page title settings
    $tourm_page_title_settings.on("change",function(){
        if( $(this).val() == 'default' ) {
            $(".cmb2-id--tourm-custom-page-title").hide();
        } else {
            $(".cmb2-id--tourm-custom-page-title").show();
        }
    });
    
})(jQuery);